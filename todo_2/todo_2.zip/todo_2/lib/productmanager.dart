import 'package:flutter/material.dart';

import'./products.dart';

class ProductManager extends StatefulWidget
{
  final String startingProduct;
  ProductManager({this.startingProduct='sweetes testeer'});//constructor
  State<StatefulWidget>  createState()
  {
    return _ProductManagerState();
  }

}

class _ProductManagerState extends State<ProductManager>
{
  List<String>_products=[];//array of string named products

  @override
  void initState()
  {
    // TODO: implement initState
    _products.add(widget.startingProduct);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Column(
        children:
        [ Container
          (
          margin:EdgeInsets.all(10.0),
          child:RaisedButton
            (
            color: Theme.of(context).primaryColor,//same color as used before
            onPressed: ()
              {
              setState(()
                {
              _products.add('Advanced food tester');
                }
                );

              },
            child:Text("add it"),
            )
          ),
    Products(_products )]);
  }
}