import 'package:flutter/material.dart';

class Products extends StatelessWidget
{
  List<String>_products;

  Products(this._products);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Column
      (
        children :_products.map
          (
                (element) =>Card
                  (
                  child:Column
                    (
                      children: <Widget>
                      [
                        Image.asset('assets/fifth.jpg'),Text(element)
                      ],
                    )
                  )
          ).toList(),
      );
  }
}
