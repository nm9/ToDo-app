import 'package:flutter/material.dart';
import 'dart:async';
import 'package:scrolling_day_calendar/scrolling_day_calendar.dart';
import 'package:intl/intl.dart';
import 'form.dart';
void main() => runApp(MaterialApp(
      home: App1(),
    ));

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text("IT WORKS"),
        ),
        body: new Checkbox(
            value: false,
            onChanged: (bool newValue) {
              Navigator.pop(context); // Pop from stack
            }));
  }
}

class ThirdScreen extends StatelessWidget
{
  Widget build(BuildContext context)
  {
    return new Scaffold(

    );
  }

}


class App1 extends StatefulWidget {
  @override
  _State createState() => new _State();
}


class _State extends State<App1>{
  List<int> numbers =[1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0];


  @override
  Widget build(BuildContext context) {
    int i=-1;
      DateTime _date = DateTime.now();
    Container elements(int) {
      i=i+1;
      var now = (DateTime.now());
      var now2 = now.add(new Duration(days : i));
      return Container(
        child: FlatButton(
            onPressed: () {
              Navigator.push(
                context,
                new MaterialPageRoute(builder: (context) => new SecondScreen()),
              );
            },
            child: Text(
              DateFormat.MMMd().format(now2),
              //now2.day.toString()+"/"+now2.month.toString(),
              style: TextStyle(color: Colors.white, fontSize: 16.0),
            )),
      );
    }

    Future _selectDate() async {
      DateTime picked = await showDatePicker(
          context: context,
          initialDate: new DateTime.now(),
          firstDate: new DateTime(2016),
          lastDate: new DateTime(2020)
      );
      if(picked != null && picked != _date)
        {
          print('date selected : ${_date.toString()}');
          setState(() {
            _date=picked;

          }
          );
        }
      Navigator.push(
        context,
        new MaterialPageRoute(builder: (context) => new SecondScreen()),
      );
    }



    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.calendar_today,),
        onPressed: (){_selectDate();},
      ),
      appBar: AppBar(
        title: Text('Horizontal ListView'),
      ),
      body:
      Container(
        //padding: EdgeInsets.symmetric(horizontal: 10.0, vertical:5.0),
        height: MediaQuery.of(context).size.height * 0.12,
        child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: numbers.length,
            itemBuilder: (context, index) {
              return Container(
                //width: MediaQuery.of(context).size.width * 0.15,
                child: Card(shape: CircleBorder(),color: Colors.blue, child: elements(index)),
              );
            }),
      ),


    );
  }

  }

