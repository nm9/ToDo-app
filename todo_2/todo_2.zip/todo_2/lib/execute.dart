import 'package:flutter/material.dart';
import 'main.dart';

class TodoListState extends State<TodoList> {
  List<String> _todoItems = [];

  void _addTodoItem(String task) {
    if (task.length > 0) {
      setState(() => _todoItems.add(task)); //writing new task
    }
  }

  Widget _buildTodoList() {
    return ListView.builder(
      itemBuilder: (context, index) {
        if (index < _todoItems.length) {
          return _buildTodoItem(_todoItems[index], index);
        }
      },
    );
  }

  Widget _buildTodoItem(String todoText, int index) {
    return ListTile(
        title: Text(todoText), onTap: () => _promptRemoveTodoItem(index));
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tasks'), centerTitle: true),
      body: _buildTodoList(),
      floatingActionButton: FloatingActionButton(
          backgroundColor: Theme.of(context).accentColor,
          onPressed: _pushAddTodoScreen,
          tooltip: 'Add task',
          child: Icon(Icons.add)),
    );
  }

  int selector;
  Color _getColor(int selector) {
    if (selector % 4 == 0) {
      return Colors.red[300];
    } else if (selector % 4 == 1) {
      return Colors.amber[300];
    } else if (selector % 4 == 2) {
      return Colors.blue[300];
    } else if (selector % 4 == 3) {
      return Colors.green[300];
    }
  }

  void _pushAddTodoScreen() {
    Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      //multipage app, transfers to new page
      return Scaffold(
          appBar: AppBar(title: Text('Add a  task')),
          body: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Card(
                    margin: EdgeInsets.all(6.0),
                      color: Colors.red[300],
                      child: Column(children: <Widget>[
                        Text("Urgent and Important"),
                        Icon(Icons.priority_high),
                        RaisedButton(
                          child: Text('Add Task'),
                          onPressed: () {
                            _getColor(0);
                            _newTask();
                          },
                        )
                      ])),
                  Card(
                    margin: EdgeInsets.all(6.0),
                      color: Colors.amber[300],
                      child: Column(children: <Widget>[
                        Text("Urgent not Important"),
                        Icon(Icons.access_time),
                        RaisedButton(
                          child: Text('Add Task'),
                          onPressed: () {
                            _getColor(1);
                            _newTask();
                          },
                        )
                      ])),
                ],
              ),
              Row(
                children: <Widget>[
                  Card(
                    margin: EdgeInsets.all(6.0),
                      color: Colors.blue[300],
                      child: Column(children: <Widget>[
                        Text("Important not urgent"),
                        Icon(Icons.notification_important),
                        RaisedButton(
                          child: Text('Add Task'),
                          onPressed: () {
                            _getColor(2);
                            _newTask();
                          },
                        )
                      ])),
                  Card(
                    margin: EdgeInsets.all(6.0),
                      color: Colors.green[300],
                      child: Column(children: <Widget>[
                        Text("Neither Urgent nor Important"),
                        Icon(Icons.low_priority),
                        RaisedButton(
                          child: Text('Add Task'),
                          onPressed: () {
                            _getColor(3);
                            _newTask();
                          },
                        )
                      ])),
                ],
              ),
            ],
          ));
    }));
  }

  void _newTask() {
    Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return Scaffold(
        appBar: AppBar(title: Text("What's your task?")),
        backgroundColor: _getColor(selector),
        body: TextField(
          autofocus: true,
          onSubmitted: (val) {
            _addTodoItem(val);
            Navigator.pop(context);
          },
          decoration: InputDecoration(
              hintText: 'Enter something to do...',
              contentPadding: const EdgeInsets.all(16.0)),
        ),
      );
    }));
  }

  void _removeTodoItem(int index) {
    setState(() => _todoItems.removeAt(index));
  }

  void _promptRemoveTodoItem(int index) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Mark "${_todoItems[index]}" as done?'),
              actions: <Widget>[
                FlatButton(
                    child: Text('CANCEL'),
                    onPressed: () => Navigator.of(context).pop()),
                FlatButton(
                    child: Text('MARK AS DONE'),
                    onPressed: () {
                      _removeTodoItem(index);
                      Navigator.of(context).pop();
                    })
              ]);
        });
  }
}
