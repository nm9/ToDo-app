import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text("IT WORKS"),
        ),
        body: new Checkbox(
            value: false,
            onChanged: (bool newValue) {
              Navigator.pop(context); // Pop from stack
            }));
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //final appTitle = 'Form Validation Demo';

    return MaterialApp(
      //title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: Text("appTitle"),
        ),
        body: MyCustomForm(),
      ),
    );
  }
}

// Create a Form widget.
class MyCustomForm extends StatefulWidget {
  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

// Create a corresponding State class.
// This class holds data related to the form.
class MyCustomFormState extends State<MyCustomForm> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a GlobalKey<FormState>,
  // not a GlobalKey<MyCustomFormState>.
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {

    DateTime _date = DateTime.now();
    TimeOfDay _time= TimeOfDay.now();

//for the calendar
    Future _selectDate() async {
      DateTime picked = await showDatePicker(
          context: context,
          initialDate: new DateTime.now(),
          firstDate: new DateTime(2016),
          lastDate: new DateTime(2020)
      );
      if(picked != null && picked != _date)
      {
        print("date selected : ${_date.toString()}");
        setState(() {
          _date=picked;

        }
        );
      }
      Navigator.push(
        context,
        new MaterialPageRoute(builder: (context) => new SecondScreen()),
      );
    }
    //here the calendar ends

    Future _selectTime(BuildContext context) async{
        final TimeOfDay picked = await showTimePicker(context: context, initialTime: _time);
        if(picked != null && picked != _time)
        {
          print('time selected : ${_time.toString()}');
          setState(() {
            _time=picked;

          }
          );
        }
    }

    // Build a Form widget using the _formKey created above.
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(
              hintText: "enter here : ",
            ),
            //enabled:false,
            //initialValue: "enter your note here",
            keyboardType: TextInputType.multiline,
            maxLines: 7,
            autofocus: true,
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter some text';
              }
              return null;
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: RaisedButton(
              onPressed: () {
                // Validate returns true if the form is valid, or false
                // otherwise.
                if (_formKey.currentState.validate()) {
                  // If the form is valid, display a Snackbar.
                  Scaffold.of(context)
                      .showSnackBar(SnackBar(content: Text('Processing Data')));
                }
              },
              child: Text('Submit'),
            ),
          ),

          IconButton
            (
              icon: Icon(Icons.calendar_today),
            onPressed: _selectDate,
          ),
          new Text(" "),
          IconButton
            (
            icon : Icon(Icons.access_alarm),
                onPressed:() {_selectTime(context);},
          ),
        ],
      ),
    );



  }
}